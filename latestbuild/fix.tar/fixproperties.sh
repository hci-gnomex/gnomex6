#!/bin/bash
echo hci.mailserver=$GNOMEX_MAILSERVER >>fixedcat
echo hci.gnomex.url=jdbc:mysql://$GNOMEX_DBHOSTIP:$GNOMEX_DBPORT/gnomex?noAccessToProcedureBodies=true >>fixedcat
echo hci.gnomexguest.url=jdbc:mysql://$GNOMEX_DBHOSTIP:$GNOMEX_DBPORT/gnomex?noAccessToProcedureBodies=true >>fixedcat
echo hci.gnomexguest.password=$GNOMEXGUEST_PASSWORD >>fixedcat
echo hci.gnomex.password=$GNOMEX_PASSWORD >>fixedcat

cat fixedcat >>catalina.properties
mv -f catalina.properties /home/u0974549/tomcat8523/conf/catalina.properties

echo key=$GNOMEX_KEY >/properties/gnomex_tomcat.properties
echo key=$GNOMEX_KEY >/properties/gnomex_tomcat1.properties


